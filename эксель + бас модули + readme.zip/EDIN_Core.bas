Attribute VB_Name = "modEDIN_Core"
Option Explicit
' =============================================================================
' EDIN Core v1.3 � 16.09.2026
' ��������� ���� ��� EDIN Opportunity Monitor.
' ���������� "ByRef argument type mismatch": ��������/��������� ���������
' ���������� ByVal. ������������ ���� ���� ��� ����������� VBA-������.
' =============================================================================

Public gCol As Long
Private gPrevCalculation As XlCalculation
Private gPrevScreenUpdating As Boolean
Private gPrepActive As Boolean

Public Function DS(ByVal n As String) As Worksheet
    Set DS = ThisWorkbook.Worksheets(n)
End Function

Public Function VisRng(ws As Worksheet, ByRef totalRows As Long) As Range
    Dim d As Range
    Dim lc As Long
    Dim lr As Long

    lc = ws.Cells(1, ws.Columns.Count).End(xlToLeft).Column
    lr = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    If lr < 2 Then
        totalRows = 0
        Set VisRng = ws.Range(ws.Cells(ws.Rows.Count, 1), ws.Cells(ws.Rows.Count, lc))
        Exit Function
    End If
    Set d = ws.Range(ws.Cells(2, 1), ws.Cells(lr, lc))
    totalRows = d.Rows.Count

    On Error Resume Next
    Set VisRng = d.SpecialCells(xlCellTypeVisible)
    On Error GoTo 0

    If VisRng Is Nothing Then
        ' ������ ��������� ������� �� ������ ������������ �� ��� �������.
        ' ���������� ������ ����������� ������ ���������� ������.
        Set VisRng = ws.Range(ws.Cells(ws.Rows.Count, 1), ws.Cells(ws.Rows.Count, lc))
    End If
End Function

Public Function ColByTitle(ws As Worksheet, ByVal ttl As String) As Long
    Dim c As Range

    On Error Resume Next
    Set c = ws.Rows(1).Find(What:=ttl, LookIn:=xlValues, LookAt:=xlWhole)
    On Error GoTo 0

    If Not c Is Nothing Then
        ColByTitle = c.Column
    Else
        ColByTitle = 0
    End If
End Function

Public Function FilterDesc(ws As Worksheet, ByVal visCount As Long, ByVal totalRows As Long) As String
    Dim s As String
    Dim i As Long
    Dim crit As String

    s = ""

    On Error Resume Next
    If ws.AutoFilterMode Then
        For i = 1 To ws.AutoFilter.Filters.Count
            If ws.AutoFilter.Filters(i).On Then
                crit = CStr(ws.AutoFilter.Filters(i).Criteria1)
                s = s & "[" & CStr(ws.Cells(1, ws.AutoFilter.Range.Column + i - 1).Value) & "] " & crit & "; "
            End If
        Next i
    End If
    On Error GoTo 0

    If Len(s) = 0 Then
        FilterDesc = "��� ������� (��� �������), �����: " & Format(totalRows, "#,##0")
    Else
        FilterDesc = "������: " & s & " ������ " & Format(visCount, "#,##0") & " �� " & Format(totalRows, "#,##0")
    End If
End Function

Public Sub AggCount(vr As Range, ByVal keyCol As Long, d As Object)
    Dim a As Range
    Dim c As Range
    Dim k As String

    For Each a In vr.Areas
        For Each c In a.Columns(keyCol).Cells
            k = Trim$(CStr(c.Value2))
            If Len(k) > 0 Then d(k) = d(k) + 1
        Next c
    Next a
End Sub

Public Sub AggSum(vr As Range, ByVal keyCol As Long, ByVal valCol As Long, d As Object)
    Dim a As Range
    Dim i As Long
    Dim k As String
    Dim v As Double

    For Each a In vr.Areas
        For i = 1 To a.Rows.Count
            k = Trim$(CStr(a.Cells(i, keyCol).Value2))
            v = 0

            If IsNumeric(a.Cells(i, valCol).Value2) Then
                v = CDbl(a.Cells(i, valCol).Value2)
            End If

            If Len(k) > 0 Then d(k) = d(k) + v
        Next i
    Next a
End Sub

Public Sub EmitAgg(d As Object, ByVal r0 As Long, ByVal maxRows As Long, ByVal orderMode As Long, _
                   ByRef catR As Range, ByRef valR As Range, ByRef nRows As Long)
    Dim calc As Worksheet
    Dim i As Long
    Dim k As Variant
    Dim cnt As Long
    Dim rg As Range

    Set calc = DS("Calc")
    cnt = d.Count

    If cnt = 0 Then
        ' ������ ���������� �������� ���������: ����� �� ������ ���������
        ' ���������� ��������� ��� ������ �� ��������� ������ �������.
        calc.Cells(r0, gCol).Value = "��� ������"
        calc.Cells(r0, gCol + 1).Value = 0
        Set catR = calc.Cells(r0, gCol)
        Set valR = calc.Cells(r0, gCol + 1)
        nRows = 1
        gCol = gCol + 3
        Exit Sub
    End If

    i = 0
    For Each k In d.Keys
        calc.Cells(r0 + i, gCol).Value = CStr(k)
        calc.Cells(r0 + i, gCol + 1).Value = d(k)
        i = i + 1
    Next k

    Set rg = calc.Range(calc.Cells(r0, gCol), calc.Cells(r0 + cnt - 1, gCol + 1))

    Select Case orderMode
        Case 1
            rg.Sort Key1:=calc.Cells(r0, gCol + 1), Order1:=xlDescending, Header:=xlNo
        Case 2
            rg.Sort Key1:=calc.Cells(r0, gCol), Order1:=xlAscending, Header:=xlNo
        Case Else
            rg.Sort Key1:=calc.Cells(r0, gCol + 1), Order1:=xlAscending, Header:=xlNo
    End Select

    nRows = Application.Min(cnt, maxRows)
    Set catR = calc.Range(calc.Cells(r0, gCol), calc.Cells(r0 + nRows - 1, gCol))
    Set valR = calc.Range(calc.Cells(r0, gCol + 1), calc.Cells(r0 + nRows - 1, gCol + 1))

    gCol = gCol + 3
End Sub

Public Sub ClearReportGraphics(ws As Worksheet)
    Dim i As Long

    On Error Resume Next

    For i = ws.ChartObjects.Count To 1 Step -1
        If ws.ChartObjects(i).Name Like "EA_*" Then ws.ChartObjects(i).Delete
    Next i

    ws.Shapes("EA_Concl").Delete

    On Error GoTo 0
End Sub

Public Sub AddChart(wsR As Worksheet, ByVal anchor As String, ByVal w As Single, ByVal h As Single, ByVal ttl As String, _
                    ByVal ct As Long, catR As Range, valR As Range, ByVal clr As Long, ByVal legend As Boolean)
    Dim co As ChartObject
    Dim ch As Chart
    Dim s As Series
    Dim slot As Range
    Dim i As Long
    Dim pal

    Set slot = EDIN_ChartSlot(wsR, anchor)
    Set co = wsR.ChartObjects.Add(slot.Left + 2, slot.Top + 2, _
                                  Application.Max(20, slot.Width - 4), _
                                  Application.Max(20, slot.Height - 4))
    co.Name = "EA_" & wsR.Name & "_" & Replace(anchor, "$", "")
    co.Placement = xlFreeFloating

    Set ch = co.Chart
    ch.ChartType = ct

    Do While ch.SeriesCollection.Count > 0
        ch.SeriesCollection(1).Delete
    Loop

    Set s = ch.SeriesCollection.NewSeries
    s.Values = valR
    s.XValues = catR
    s.Name = ttl

    ch.HasTitle = True
    ch.ChartTitle.Text = ttl
    ch.PlotVisibleOnly = False

    If ct = xlDoughnut Or ct = xlPie Then
        ch.HasLegend = True
        ch.Legend.Position = xlLegendPositionBottom
    Else
        ch.HasLegend = False
    End If

    On Error Resume Next

    If ct = xlDoughnut Or ct = xlPie Then
        pal = Array( _
            RGB(46, 116, 181), _
            RGB(112, 173, 71), _
            RGB(255, 192, 0), _
            RGB(237, 125, 49), _
            RGB(165, 165, 165), _
            RGB(68, 84, 106))

        For i = 1 To s.Points.Count
            s.Points(i).Format.Fill.ForeColor.RGB = pal((i - 1) Mod 6)
        Next i

        s.ApplyDataLabels
        With s.DataLabels
            .ShowCategoryName = True
            .ShowValue = False
            .ShowPercentage = True
            .ShowSeriesName = False
            .Separator = vbLf
            .Font.Size = 8
        End With
    Else
        s.Format.Fill.ForeColor.RGB = clr
        s.Format.Line.ForeColor.RGB = clr

        s.ApplyDataLabels
        With s.DataLabels
            .ShowValue = True
            .ShowSeriesName = False
            .ShowCategoryName = (ct = xlBarClustered Or ct = xlBarStacked Or ct = xlBarStacked100)
            .Separator = vbLf
            .NumberFormat = EDIN_ChartNumberFormat(ttl)
            .Font.Size = 8
        End With
    End If

    If ch.HasAxis(xlCategory, xlPrimary) Then
        With ch.Axes(xlCategory, xlPrimary)
            .HasTitle = True
            .AxisTitle.Text = EDIN_CategoryAxisTitle(ttl)
            .TickLabelPosition = xlTickLabelPositionNextToAxis
            .TickLabels.Font.Size = 8
        End With
    End If
    If ch.HasAxis(xlValue, xlPrimary) Then
        With ch.Axes(xlValue, xlPrimary)
            .HasTitle = True
            .AxisTitle.Text = EDIN_ValueAxisTitle(ttl)
            .TickLabels.NumberFormat = EDIN_ChartNumberFormat(ttl)
            .TickLabels.Font.Size = 8
            .MajorGridlines.Format.Line.ForeColor.RGB = RGB(217, 225, 242)
        End With
    End If

    On Error GoTo 0
End Sub

Private Function EDIN_ChartSlot(ByVal wsR As Worksheet, ByVal anchor As String) As Range
    Select Case UCase$(Replace(anchor, "$", ""))
        Case "B8": Set EDIN_ChartSlot = wsR.Range("B8:G22")
        Case "H8": Set EDIN_ChartSlot = wsR.Range("H8:M22")
        Case "B23": Set EDIN_ChartSlot = wsR.Range("B23:G37")
        Case "H23": Set EDIN_ChartSlot = wsR.Range("H23:M37")
        Case "B38": Set EDIN_ChartSlot = wsR.Range("B38:G52")
        Case "H38": Set EDIN_ChartSlot = wsR.Range("H38:M52")
        Case Else: Set EDIN_ChartSlot = wsR.Range(anchor).Resize(15, 6)
    End Select
End Function

Private Function EDIN_CategoryAxisTitle(ByVal chartTitle As String) As String
    Dim t As String: t = LCase$(chartTitle)
    If InStr(t, "���") > 0 Or InStr(t, "year") > 0 Or InStr(t, "�������") > 0 Then
        EDIN_CategoryAxisTitle = "���"
    ElseIf InStr(t, "�����") > 0 Then
        EDIN_CategoryAxisTitle = "������"
    ElseIf InStr(t, "������") > 0 Then
        EDIN_CategoryAxisTitle = "������"
    ElseIf InStr(t, "�������") > 0 Then
        EDIN_CategoryAxisTitle = "������ / ���������"
    ElseIf InStr(t, "��������") > 0 Then
        EDIN_CategoryAxisTitle = "��������"
    ElseIf InStr(t, "�������") > 0 Then
        EDIN_CategoryAxisTitle = "�������"
    ElseIf InStr(t, "��������") > 0 Then
        EDIN_CategoryAxisTitle = "���������� �������"
    ElseIf InStr(t, "��������") > 0 Then
        EDIN_CategoryAxisTitle = "��������"
    ElseIf InStr(t, "������") > 0 Then
        EDIN_CategoryAxisTitle = "�������"
    Else
        EDIN_CategoryAxisTitle = "���������"
    End If
End Function

Private Function EDIN_ValueAxisTitle(ByVal chartTitle As String) As String
    Dim t As String: t = LCase$(chartTitle)
    If InStr(t, "�����") > 0 Or InStr(t, "usd") > 0 Or InStr(t, "us$") > 0 Then
        EDIN_ValueAxisTitle = "USD"
    ElseIf InStr(t, "������") > 0 Or InStr(t, "mmboe") > 0 Or InStr(t, "�.�.�") > 0 Then
        EDIN_ValueAxisTitle = "��� �.�.�. (MMboe)"
    ElseIf InStr(t, "������") > 0 Or InStr(t, "sqkm") > 0 Or InStr(t, "��2") > 0 Then
        EDIN_ValueAxisTitle = "��2"
    Else
        EDIN_ValueAxisTitle = "����������, ��."
    End If
End Function

Private Function EDIN_ChartNumberFormat(ByVal chartTitle As String) As String
    If EDIN_ValueAxisTitle(chartTitle) = "USD" Then
        EDIN_ChartNumberFormat = "$#,##0;($#,##0);-"
    Else
        EDIN_ChartNumberFormat = "#,##0;(#,##0);-"
    End If
End Function

Public Sub WriteKPIs(wsR As Worksheet, ByVal v1 As String, ByVal v2 As String, ByVal v3 As String, ByVal v4 As String, ByVal v5 As String)
    On Error Resume Next

    wsR.Range("B6").Value = v1
    wsR.Range("D6").Value = v2
    wsR.Range("F6").Value = v3
    wsR.Range("H6").Value = v4
    wsR.Range("J6").Value = v5

    On Error GoTo 0
End Sub

Public Sub WriteConclusions(wsR As Worksheet, ByVal header As String, ByVal body As String, ByVal anchor As String)
    Dim sh As Shape
    Dim a As Range

    Set a = wsR.Range(anchor)

    On Error Resume Next
    wsR.Shapes("EA_Concl").Delete
    On Error GoTo 0

    Set sh = wsR.Shapes.AddTextbox(msoTextOrientationHorizontal, a.Left, a.Top, 1020, 250)
    sh.Name = "EA_Concl"

    With sh.TextFrame2
        .TextRange.Text = header & vbCrLf & body
        .TextRange.Font.Size = 10
        .WordWrap = msoTrue
        .MarginLeft = 10
        .MarginTop = 8
    End With

    sh.Fill.ForeColor.RGB = RGB(242, 246, 251)
    sh.Line.ForeColor.RGB = RGB(46, 116, 181)
    sh.Line.Weight = 1.25
End Sub

Public Function MedianOf(vr As Range, ByVal col As Long) As Double
    Dim a As Range
    Dim i As Long
    Dim arr() As Double
    Dim n As Long
    Dim v As Variant

    n = 0

    For Each a In vr.Areas
        For i = 1 To a.Rows.Count
            v = a.Cells(i, col).Value2

            If IsNumeric(v) Then
                n = n + 1
                ReDim Preserve arr(1 To n)
                arr(n) = CDbl(v)
            End If
        Next i
    Next a

    If n = 0 Then
        MedianOf = 0
    Else
        MedianOf = WorksheetFunction.Median(arr)
    End If
End Function

Public Function SumCol(vr As Range, ByVal col As Long) As Double
    Dim a As Range
    Dim i As Long
    Dim t As Double

    t = 0

    For Each a In vr.Areas
        For i = 1 To a.Rows.Count
            If IsNumeric(a.Cells(i, col).Value2) Then
                t = t + CDbl(a.Cells(i, col).Value2)
            End If
        Next i
    Next a

    SumCol = t
End Function

Public Function CountVisible(vr As Range, ByVal keyCol As Long) As Long
    Dim a As Range
    Dim i As Long
    Dim t As Long

    t = 0

    For Each a In vr.Areas
        For i = 1 To a.Rows.Count
            If Len(Trim$(CStr(a.Cells(i, keyCol).Value2))) > 0 Then t = t + 1
        Next i
    Next a

    CountVisible = t
End Function

Public Function FmtN(ByVal v As Double) As String
    FmtN = Replace(Format$(v, "#,##0"), ",", " ")
End Function

Public Function Fmt1(ByVal v As Double) As String
    Fmt1 = Replace(Format$(v, "#,##0.0"), ",", " ")
End Function

Public Sub Prep(ByVal runStart As Long, Optional ByVal workspace As String = "")
    On Error Resume Next

    Select Case LCase$(workspace)
        Case "farmin": gCol = 28       ' AB:AS
        Case "awards": gCol = 46       ' AT:BK
        Case "active": gCol = 64       ' BL:CC
        Case "planned": gCol = 82      ' CD:CU
        Case Else: gCol = 28
    End Select

    gPrevCalculation = Application.Calculation
    gPrevScreenUpdating = Application.ScreenUpdating
    gPrepActive = True
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual

    DS("Calc").Range( _
        DS("Calc").Cells(runStart, gCol), _
        DS("Calc").Cells(runStart + 10000, gCol + 17) _
    ).ClearContents

    On Error GoTo 0
End Sub

Public Sub Fin()
    If gPrepActive Then
        Application.Calculation = gPrevCalculation
        Application.ScreenUpdating = gPrevScreenUpdating
        gPrepActive = False
    Else
        Application.ScreenUpdating = True
    End If
End Sub

Public Function DepthBucket(ByVal v As Variant) As String
    Dim x As Double

    If Not IsNumeric(v) Then
        DepthBucket = "Onshore/ND"
        Exit Function
    End If

    x = CDbl(v)

    Select Case True
        Case x > 1250
            DepthBucket = "Deepwater (>1250)"
        Case x > 500
            DepthBucket = "Deep (500-1250)"
        Case x > 200
            DepthBucket = "Shelf (200-500)"
        Case x > 0
            DepthBucket = "Shallow (0-200)"
        Case Else
            DepthBucket = "Onshore/ND"
    End Select
End Function
